import {useState} from "react";
import "./App.css";
import Resume from "./images/resume.png";
import { useNavigate } from "react-router-dom";
import { useLocation } from "react-router-dom";

function Mybio() {
const location = useLocation();
const data = location.state;
const navigate = useNavigate();

console.log(data)
const edit = ()=>{
    navigate("/my-bio-edit");
}
const skills = ()=>{
    navigate("/skills");
}

    return(
        <div className="mybio">
            <h2><i class="fa-solid fa-angle-left"></i>  My bio</h2>
            <div className="about">
            <span className="about-head">About Me</span>
            <span className="pen"><button className="edit" onClick={edit}><i class="fa-solid fa-pen"></i></button></span>
            <div className="about-content">
                <p>{data.about}</p>
                <hr className="about-line"/>
            </div>
            </div>

            <div className="about">
                <span className="about-head">Blood Group</span>
                <span className="pen">{data.blood}</span>
            </div>

            <div className="resume">
            <span><img src={Resume} className="resume-img"/></span>
            <span className="resume-text">Resume</span>
            <span className="pen"><i class="fa-solid fa-angle-right"></i></span>
            {data.resume && <embed src={data.resume} width="400px" height="200px" type="pdf"></embed>}
            </div>
    
            <div className="about">
            <span className="about-head">Skills</span>
            <span className="pen"><button className="edit" onClick={skills}><i class="fa-solid fa-pen"></i></button></span>
            <div className="skills-content">
                <div className="skill-box">
                <p></p>
                </div>
            </div>
            </div>
           
        </div>
    )
}

export default Mybio;