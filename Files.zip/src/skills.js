
import { useNavigate } from "react-router-dom"

function Skills() {
const navigate = useNavigate()
const saveskills = ()=>{
    navigate("/")
}
    return(
        <div>
            <h1>My skills are/I'm professionally good at</h1>
            <span>Select Skills</span>
            <input type="checkbox">HTML</input>
            <input type="checkbox">CSS</input>
            <button onClick={saveskills}>Save</button>
        </div>

       
    )
}

export default Skills;