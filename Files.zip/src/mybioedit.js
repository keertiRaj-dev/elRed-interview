import { useNavigate } from "react-router-dom";
import "./App.css";
import { useState, useEffect } from "react";
import Resume from "./images/resume.png"

function MybioEdit() {
const navigate= useNavigate();
const [newAbout, setNewAbout] = useState("No about me added yet");
const [newResume, setNewResume] = useState();
const [newBloodGroup, setNewBloodGroup] = useState("");
const [newSkills, setNewSkills] = useState([]);

const save =()=> {
const data = {about: newAbout, resume: newResume, blood: newBloodGroup, skills: newSkills};
navigate("/", {state: data})
}

const fetchskills = async()=>{
    await fetch("https://docs.google.com/spreadsheets/d/1EylsJkqOZ2qAQ9IanYa9c9lJYYxSlh_4NS9h1KMcJmo/edit?usp=sharing ")
    .then(response=>response.json())
    .then(data=>setNewSkills(data))
}

useEffect(()=>{
    fetchskills()
}, [])

const back =()=>{
    navigate("/");
}
console.log(newAbout);
console.log(newBloodGroup)
console.log(newSkills)
return(
    <div className="mybio"> 
     <span></span><button onClick={back} className="edit"><i className="fa-solid fa-angle-left"></i> </button><span><h2>My bio</h2></span>
     <h1 className="about">Write something about yourself</h1>
     <input className="about-input" type="text" placeholder="Write something here..." onChange={(event)=>setNewAbout(event.target.value)} />
    <div className="resume-upload">
        <img src={Resume} className="resume-img-upload"/>
        <input type="file" accept="pdf/jpg/jpeg/png" placeholder="Upload Resume" onChange={(event)=>setNewResume(event.target.value)}/>
        {newResume && <embed src={newResume} width="400px" height="200px" type="pdf/png/jpg/jpeg"></embed> }
    {newResume && <button onClick={()=>setNewResume(null)}> Delete Resume </button>}
    </div>

    <div className="edit-blood">
        <h1>Choose Blood Group</h1>
        <span>Select blood group</span><select className="blood-dropdown" onChange={(event)=>setNewBloodGroup(event.target.value)}>
            <option value="A+" className="blood-option">A+</option>
            <option value="A-" className="blood-option">A-</option>
            <option value="B+" className="blood-option">B+</option>
            <option value="B-" className="blood-option">B-</option>
            <option value="AB+" className="blood-option">AB+</option>
            <option value="AB-" className="blood-option">AB-</option>
            <option value="O+" className="blood-option">O+</option>
            <option value="O-" className="blood-option">O-</option>
        </select>
    </div>

    

    <button onClick={save} >Save</button>
    
    </div>
)
}

export default MybioEdit;